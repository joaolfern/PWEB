const express = require('express')

const app = express()

app.listen(3000, () => {
    console.log('servidor com express foi carregado')
})